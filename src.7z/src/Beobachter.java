
interface Beobachter {
	public void aktualisieren(MessDaten daten);
}

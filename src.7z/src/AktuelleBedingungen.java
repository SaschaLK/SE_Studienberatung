import java.util.Observable;
import java.util.Observer;

public class AktuelleBedingungen implements Observer{
	@Override
	public void update(Observable o,Object arg) {
		MessDaten daten = (MessDaten)arg;
		System.out.println("aktuell: " 
				+ daten.getTemperatur() + " C " 
				+ daten.getFeuchtigkeit() + "% "
				+ daten.getDruck() + " hPa ");
	}

//	@Override
//	public void update(Observable o, Object arg) {
//		// TODO Auto-generated method stub
//		
//	}
}

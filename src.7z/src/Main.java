
public class Main {

	public static void main(String[] args) {
		Wetterstation wetterstation = new Wetterstation();
		
		wetterstation.addObserver(new AktuelleBedingungen());
		wetterstation.addObserver(new Aussichten());
		wetterstation.addObserver(new Tendenz());
	}
}

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;

import javax.swing.Timer;


public class Wetterstation extends Observable {
	MessDaten daten = new MessDaten();
	
	
//	ArrayList<Beobachter> beobachterListe = new ArrayList<>();
//	public void addBeobachter (Beobachter beobachter) {
//		beobachterListe.add(beobachter);
//	}
//	public void removeBeobacter (Beobachter beobachter){
//		beobachterListe.remove(beobachter);
//	}
//	public void messwerteGeaendert(){
//		for(Beobachter beobachter: beobachterListe){
//			beobachter.aktualisieren(daten);
//		}
//	}
/*	
	AktuelleBedingungen aktuelleBedingungen = new AktuelleBedingungen();
	Tendenz tendenz = new Tendenz();
	Aussichten aussichten = new Aussichten();
	
	
	
	// wird aufgerufen, wenn neue Messwerte da sind
	public void messwerteGeaendert(){		
		aktuelleBedingungen.aktualisieren(daten);
		tendenz.aktualisieren(daten);
		aussichten.aktualisieren(daten);
	}
*/	
	
	// Simulation der Wetterdaten ...
	public void messungSimulieren(){
		Thread thread = new Thread(new Runnable(){
			public void run(){
				while (true){
					daten.messen();
					setChanged();
					notifyObservers(daten);
					clearChanged();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}
			}
		});
		thread.start();
	}

	public Wetterstation(){
		messungSimulieren();
	}
}
